/* PAGE STRUCTURE */

/* Ascensor Settings */
var ascensor = jQuery('#ascensorBuilding').ascensor({
    time: 1000,
    childType: 'section',
    swipeNavigation: false,
    easing: 'easeInOutQuint',
    loop: false,
    direction: 'y',
    keyNavigation: false
});
var ascensorInstance = jQuery('#ascensorBuilding').data('ascensor');

/* Add class to the active menu item */
jQuery(".links-to-floor-li:eq(" + ascensor.data("current-floor") + ")").addClass("cv-active");

/* Menu click event */
jQuery('body').find('.links-to-floor-li').on("click", function (e) {
    "use strict";
    e.preventDefault();
    /* Get the id of the floor */
    var floornumber = jQuery(this).data('id');
    /* Remove class from all menu items */
    jQuery('body').find('.links-to-floor-li').removeClass("cv-active");
    /* Add class to the active menu item */
    jQuery(this).addClass("cv-active");
    /* Close sidebar */
    jQuery("body").find(".cv-menu-button").removeClass("rotate-menu-icon");
    jQuery("#cv-sidebar").removeClass("open");
    /* Scroll the page */
    window.location.hash = jQuery(this).data('slug');
    jQuery("#cv-left-slider").gotoSlide(floornumber);
    ascensorInstance.scrollToFloor(floornumber - 1);
    /* Footer animation */
    if (floornumber === 1) {
        jQuery("#footer").animate({
            bottom: '-100%'
        }, 1000);
    } else {
        jQuery("#footer").animate({
            bottom: 0
        }, 1000);
    }
});

/* GO TO FLOOR LINK */

jQuery('body').find('.go-to-floor').on("click", function (e) {
    "use strict";
    e.preventDefault();
    /* Get the id of the floor */
    var floornumber = jQuery(this).data('id');
    /* Remove class from all menu items */
    jQuery('body').find('.links-to-floor-li').removeClass("cv-active");
    /* Add class to the active menu item */
    jQuery('.links-to-floor-li[data-id="' + floornumber + '"]').addClass('cv-active');
    /* Close sidebar */
    jQuery("body").find(".cv-menu-button").removeClass("rotate-menu-icon");
    jQuery("#cv-sidebar").removeClass("open");
    /* Scroll the page */
    window.location.hash = jQuery(this).data('slug');
    jQuery("#cv-left-slider").gotoSlide(floornumber);
    ascensorInstance.scrollToFloor(floornumber - 1);
    /* Footer animation */
    if (floornumber === 1) {
        jQuery("#footer").animate({
            bottom: '-100%'
        }, 1000);
    } else {
        jQuery("#footer").animate({
            bottom: 0
        }, 1000);
    }
});

/* WINDOW LOAD EVENTS */

jQuery(window).on('load', function () {
    "use strict";
    var hash = window.location.hash.substr(1);
    if (window.location.hash) {
        /* Get the active page information from the page link and add/remove required classes */
        var smenu = jQuery(".links-to-floor-li").filter('[data-slug="' + hash + '"]');
        jQuery('body').find('.links-to-floor-li').removeClass("cv-active");
        smenu.addClass("cv-active");
        /* Scroll the page */
        var floornumber = jQuery(".cv-active").data('id');
        ascensorInstance.scrollToFloor(floornumber - 1);
        jQuery("#cv-left-slider").gotoSlide(floornumber);
        /* Footer Animation */
        if (floornumber === 1) {
            jQuery("#footer").animate({
                bottom: '-100%'
            }, 1000);
        } else {
            jQuery("#footer").animate({
                bottom: 0
            }, 1000);
        }
        /* Hide loading icon */
        setTimeout(function () {
            jQuery("body").find('#site-loading').fadeOut(500);
            jQuery("body").find('#site-loading-css').fadeOut(500);
        }, 1000);
    } else {
        /* Hide loading icon */
        setTimeout(function () {
            jQuery("body").find('#site-loading').fadeOut(500);
            jQuery("body").find('#site-loading-css').fadeOut(500);
        }, 1000);
    }
    /* HOMEPAGE TEXT ANIMATION */
    setTimeout(function () {
        jQuery('#home-slide-title span').fadeIn().removeClass('animated slideOutDown').addClass('animated slideInUp');
        jQuery('#home-title h1').fadeIn().removeClass('animated slideOutUp').addClass('animated slideInDown');
        jQuery('#home-title .cv-logo').fadeIn().removeClass('animated slideOutUp').addClass('animated slideInDown');
        jQuery('#home-title p').fadeIn().removeClass('animated slideOutLeft').addClass('animated slideInLeft');
        jQuery('#cv-home-social-bar-container').fadeIn().removeClass('animated slideOutDown').addClass('animated slideInUp');
    }, 1000);
    /* LOAD BLOG IMAGES */
    jQuery(".blog-img").each(function () {
        if (jQuery(this).attr('data-image')) {
            jQuery(this).backstretch(jQuery(this).data('image'), {
                fade: 500
            });
        }
    });
});

/* SUBMENU */

jQuery('#cv-sidebar').find(".cv-submenu ul > li > a").on('click', function () {
    "use strict";
    var nxt = jQuery(this).next();
    if ((nxt.is('ul')) && (nxt.is(':visible'))) {
        nxt.slideUp(300);
        jQuery(this).removeClass("cvdropdown2").addClass("cvdropdown");
    }
    if ((nxt.is('ul')) && (!nxt.is(':visible'))) {
        jQuery('#cv-sidebar').find('.cv-submenu ul ul:visible').slideUp(300);
        nxt.slideDown(100);
        jQuery('#cv-sidebar').find('.cv-submenu > ul > li:has(ul) > a').removeClass("cvdropdown2").addClass("cvdropdown");
        jQuery(this).addClass("cvdropdown2");
    }
    if (nxt.is('ul')) {
        return false;
    } else {
        return true;
    }
});

/* SIDEBAR DROPDOWN MENU */

jQuery('#cv-sidebar').find(".widget_nav_menu > div > ul > li > a").on('click', function () {
    "use strict";
    var nxt = jQuery(this).next();
    if ((nxt.is('ul')) && (nxt.is(':visible'))) {
        nxt.slideUp(300);
        jQuery(this).removeClass("cvdropdown2").addClass("cvdropdown");
    }
    if ((nxt.is('ul')) && (!nxt.is(':visible'))) {
        jQuery('#cv-sidebar').find('.widget_nav_menu > div ul ul:visible').slideUp(300);
        nxt.slideDown(100);
        jQuery('#cv-sidebar').find('.widget_nav_menu > div > ul > li:has(ul) > a').removeClass("cvdropdown2").addClass("cvdropdown");
        jQuery(this).addClass("cvdropdown2");
    }
    if (nxt.is('ul')) {
        return false;
    } else {
        return true;
    }
});

/* SIDEBAR */

jQuery("body").find(".cv-menu-button").on("click", function (e) {
    "use strict";
    e.preventDefault();
    jQuery(this).toggleClass("rotate-menu-icon");
    jQuery("#cv-sidebar").toggleClass("open");
});

/* ICON EFFECT */

jQuery('body').find(".cv-icon-container").on({
    mouseenter: function () {
        "use strict";
        jQuery(this).addClass('animated rubberBand');
    },
    mouseleave: function () {
        "use strict";
        jQuery(this).removeClass('animated rubberBand');
    }
});

/* BACK TO TOP */

jQuery("#cv-back-to-top").on('click', function (event) {
    "use strict";
    event.preventDefault();
    jQuery("body").find('.floor').animate({
        scrollTop: 0
    }, 500);
});

/* OTHER EVENTS */

jQuery(document).ready(function () {
    "use strict";   
    /* SIDEBAR CUSTOM SCROLLBAR */
    if (jQuery(window).width() > 1024) {
        jQuery("#cv-sidebar-inner").mCustomScrollbar({
            scrollInertia: 500,
            autoHideScrollbar: true,
            theme: "light-thick",
            scrollButtons: {
                enable: true
            },
            advanced: {
                updateOnContentResize: true
            }
        });
    }
    /* MENU SCROLLBAR */
    if (jQuery(window).width() > 1024) {
        jQuery("#cv-menu").mCustomScrollbar({
            scrollInertia: 0,
            autoHideScrollbar: true,
            theme: "light-thin",
            scrollButtons: {
                enable: true
            },
            advanced: {
                updateOnContentResize: true
            }
        });
    }
    
    /* ADD SUBMENU DROPDOWN ARROWS */
    jQuery('#cv-sidebar').find('.cv-submenu > ul > li:has(ul) > a').addClass("cvdropdown");
    jQuery('#cv-sidebar').find('.widget_nav_menu > div > ul > li:has(ul) > a').addClass("cvdropdown");
    
    /* SKILLS */
    jQuery("body").find('.skillbar').each(function () {
        jQuery(this).find('.skillbar-bar').width(jQuery(this).data('percent'));
    });
    
    /* LEFT SLIDER */
    jQuery("#cv-left-slider").nerveSlider({
        /* Image Slider Settings */
        sliderAutoPlay: false,
        sliderWidth: "100%",
        sliderHeight: "100%",
        slideTransitionEasing: 'easeInOutQuint',
        slideTransitionDelay: 0,
        slideTransitionSpeed: 1000,
        sliderResizable: true,
        sliderKeepAspectRatio: false,
        slideTransitionDirection: "down",
        allowKeyboardEvents: false,
        slidesDraggable: false,
        showDots: false,
        showTimer: false,
        showArrows: false,
        showPause: false,
        /* Homepage Text Animations */
        slideTransitionStart: function () {
            jQuery('#home-slide-title span').fadeOut(500).removeClass('animated slideInUp').addClass('animated slideOutDown');
            jQuery('#home-title h1').fadeOut(500).removeClass('animated slideInDown').addClass('animated slideOutUp');
            jQuery('#home-title p').fadeOut(500).removeClass('animated slideInLeft').addClass('animated slideOutLeft');
            jQuery('#home-title .cv-logo').fadeOut(500).removeClass('animated slideInDown').addClass('animated slideOutUp');
            jQuery('#cv-home-social-bar-container').fadeOut(500).removeClass('animated slideInUp').addClass('animated slideOutDown');
        },
        slideTransitionComplete: function () {
            jQuery('#home-slide-title span').fadeIn().removeClass('animated slideOutDown').addClass('animated slideInUp');
            jQuery('#home-title h1').fadeIn().removeClass('animated slideOutUp').addClass('animated slideInDown');
            jQuery('#home-title .cv-logo').fadeIn().removeClass('animated slideOutUp').addClass('animated slideInDown');
            jQuery('#home-title p').fadeIn().removeClass('animated slideOutLeft').addClass('animated slideInLeft');
            jQuery('#cv-home-social-bar-container').fadeIn().removeClass('animated slideOutDown').addClass('animated slideInUp');
        }
        /* Homepage Text Animations END */
    });
});